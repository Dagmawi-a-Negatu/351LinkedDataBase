package project1CS351;

public class Address {

}
