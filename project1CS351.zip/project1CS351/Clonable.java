package project1CS351;

public interface Clonable {

}
