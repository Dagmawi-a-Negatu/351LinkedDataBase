package project1CS351;

public class WorkContact extends Contact {
	private String title; //Job title
	private String company; //Company contact works for
	private String deparmtnet; // Contact's department
	//... 
	
	

}




